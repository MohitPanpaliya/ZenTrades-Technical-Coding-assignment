import './App.css';
import { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [data, setdata] = useState(null);
  useEffect(() => {
    if(data === null){
      axios.get('https://s3.amazonaws.com/open-to-cors/assignment.json').then((items) => {
      setdata(items);
    })
    }
  })
  console.log(data);
//   function sortByProperty(property){  
//     return function(a,b){  
//        if(a[property] > b[property])  
//           return 1;  
//        else if(a[property] < b[property])  
//           return -1;  
   
//        return 0;  
//     }  
//  }
//  data.products.sort(sortByProperty("priority"));
  
  if(data === null){
    return ("Loading");
  }
  else{
  return (
    <div className="App">
      {Object.values(data.data.products).map((item) =>(
        <div className="app__card">
          <h1>{item.title}</h1>
          <p>Rs. {item.price}</p>
        </div>
      ))}
    </div>
  );}
}

export default App;
